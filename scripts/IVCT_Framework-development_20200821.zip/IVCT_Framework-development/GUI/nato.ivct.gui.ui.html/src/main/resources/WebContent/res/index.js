$(document).ready(function() {
  var app = new scout.RemoteApp();
  app.init({
    bootstrap: {
      fonts: ['scoutIcons']
    }
  });
});
