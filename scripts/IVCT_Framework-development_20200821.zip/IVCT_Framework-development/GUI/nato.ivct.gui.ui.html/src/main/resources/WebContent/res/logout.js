$(document).ready(function() {
  new scout.LogoutApp().init();
});
