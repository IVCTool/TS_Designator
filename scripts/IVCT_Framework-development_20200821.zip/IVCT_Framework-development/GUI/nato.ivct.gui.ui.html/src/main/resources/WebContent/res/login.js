$(document).ready(function() {
  new scout.LoginApp().init();
});
