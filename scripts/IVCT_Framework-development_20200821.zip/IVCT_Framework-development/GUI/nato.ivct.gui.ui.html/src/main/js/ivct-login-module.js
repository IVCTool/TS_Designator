(function(ivct, scout, $, undefined) {
  __include("ivct/LoginBox.js");
  __include("ivct/objectFactories.js");
}(window.ivct = window.ivct || {}, scout, jQuery));