ivct.LoginBox = function(opts) {
	ivct.LoginBox.parent.call(this, opts);
};

scout.inherits(ivct.LoginBox, scout.LoginBox);

ivct.LoginBox.prototype.init = function(opts) {
	ivct.LoginBox.parent.prototype.init.call(this, opts);
};

ivct.LoginBox.prototype.init = function(opts) {
  ivct.LoginBox.parent.prototype.init.call(this, opts);

  this.logoUrl = 'res/ivct-logo.png';
};
